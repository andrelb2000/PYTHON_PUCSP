from CONTROLE import Controle
from CONTROLE2 import Controle2
##controle = Controle()
##controle.executar()

controle2 = Controle2()
controle2.executar()
