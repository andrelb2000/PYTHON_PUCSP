from VISUAL_CANVAS import *

visual = VisualCanvas(0)
visual.iniciar()




