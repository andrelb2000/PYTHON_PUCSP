from VISUAL_CANVAS import *

visual = VisualCanvas(0,None,None)
visual.iniciar()




